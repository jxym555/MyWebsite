'use strict';

exports.index = function(req, res){
    res.render('index', { title: 'Report Monitor' });
};

exports.reportfunctions = function(req, res){
    res.render('reportfunctions');
};

exports.reportviews = function(req, res){
	res.render('reportviews');
};

exports.reportfunctionsearch = function(req, res){
	res.render('reportfunctionsearch');
};

exports.reporttablestats = function(req, res){
    res.render('reporttablestats');
};

exports.reportquerywatch = function(req, res){
    res.render('reportquerywatch');
};

exports.reportbadger = function (req, res) {
    res.render('reportbadger');
};
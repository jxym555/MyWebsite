'use strict';

var servers = [
    { name : "dev8", uri : 'pg://postgres:@ladev8/', databaseName: 'dev8' },
    { name : "nztest", uri : 'pg://postgres:@app1.chc1.a.qual/', databaseName: 'app1' }
];

exports.dbServers = servers;

exports.list = function(req, res){
    res.send(JSON.stringify(servers));
};
'use strict';

var apps = [
    { name : "Report Monitor", url : "/reportmonitor" }
    ];

exports.monitorApps = apps;

exports.list = function(req, res){
    res.send(JSON.stringify(apps));
};
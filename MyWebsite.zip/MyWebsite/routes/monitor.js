'use strict';

var _ = require('lodash');
var dbServers = require('./servers').dbServers;
var pg = require('any-db-postgres');
var dbConnections = {};
var reportTableFields = ['id', 'user_id', 'server_id', 'auto_report_id', 'subject', 'report_type', 'priority', 'pid',
	'auto_report', 'file_gen_progress', 'run_start', 'run_end', 'format', 'result_path', 'queued_by_cluster',
	'status', 'estimated_size', 'deleted', 'auto_report_day', 'location', 'gen_version', 'estimated_item_count', 'report_days',
	'create_time', 'server_hostname'];
function getVersionSQL(req) {
	return 'SELECT * from reports.reports where status < 6 order by last_update desc limit 10';
}

exports.listOnServer = function(req, res) {
	executeInRequestContextSimple(getVersionSQL(req), null, req, res);
};

exports.killPid = function(req, res) {
	var pid = parseInt(req.params.pid);
	var sql = "/* pgmon */ SELECT pg_terminate_backend($1);";

	console.log("Killing with command " + sql);

	executeInRequestContextSimple(sql, [pid], req, res);
};
exports.updateReport = function(req, res) {
	var body = req.body;
	if(!body['id']) {
		res.send({'message' : 'Report id should not be empty'});
	}

	var sql = "update reports.reports set ";
	reportTableFields.forEach(function(field) {
		if(body[field]) {
			sql += field + " = '" + body[field] + "', ";
		}
	});
	sql = sql.substr(0, sql.length - 2);
	sql += " where id  = " + req.body.id;
	console.log("Update report command " + sql);

	executeInRequestContextSimple(sql, [], req, res);
};


exports.listDatabases = function(req, res) {
	var sql = "SELECT pg_database.datname as dbname, pg_user.usename as dbowner FROM pg_database, pg_user " +
		"WHERE pg_database.datdba = pg_user.usesysid AND datname NOT LIKE 'template_' UNION " +
		"SELECT pg_database.datname as dbname, NULL as dbowner FROM pg_database " +
		"WHERE pg_database.datdba NOT IN (SELECT usesysid FROM pg_user) ORDER BY dbname;";

	executeInRequestContextSimple(sql, null, req, res);
};

exports.searchViews = function(req, res) {
	var search = !req.params.search || req.params.search == "*" ? ".*" : req.params.search;
	var sql = "SELECT * FROM pg_views WHERE schemaname NOT IN ('pg_catalog', 'information_schema') " +
		"AND (schemaname ~* $1 OR viewname ~* $1 OR (schemaname || '.' || viewname) ~* $1 OR definition ~* $1) " +
		"ORDER BY viewname";

	executeInRequestContextSimple(sql, [search], req, res);
};


exports.getFunctionTimes = function(req, res) {
	var filter = (req.params.functionFilter == '*') ? '%' : '%' + req.params.functionFilter + '%';
	var sortCol = (!req.params.sortCol) ? "avg_time" : req.params.sortCol;
	var limit = (!req.params.queryLimit) ? 25 : parseInt(req.params.queryLimit);
	var sortOrder = (req.params.sortOrder == "DESC") ? "DESC" : "ASC";

	var sql = "SELECT * FROM (SELECT funcid, (schemaname || '.' || funcname) AS funcname, calls, total_time, self_time, total_time::float8/calls AS avg_time " +
		"FROM pg_stat_user_functions) AS t1 WHERE funcname ilike $1 ORDER BY " + sortCol + " " + sortOrder + " LIMIT $2";

	executeInRequestContextSimple(sql, [filter, limit], req, res);
};

exports.getFunctionDefn = function(req, res) {
	var functionId = parseInt(req.params.functionId);

	var sql = "SELECT * FROM pg_get_functiondef($1)";

	executeInRequestContextSimple(sql, [functionId], req, res);
};


exports.searchFunctionDefn = function(req, res) {
	var search = req.params.search;

	var sql = "SELECT nspname,  proname, p.oid AS relid FROM pg_catalog.pg_namespace n JOIN pg_catalog.pg_proc p ON pronamespace = n.oid WHERE nspname <> 'pg_catalog' AND (prosrc ~* $1 OR proname ~* $1) ORDER BY proname";

	executeInRequestContextSimple(sql, [search], req, res);
};

exports.getTableDefn = function(req, res) {
	var serverId = req.params.id;
	var databaseName = dbServers[serverId].databaseName
	var tableId = req.params.tableId;
	var tableName = req.params.tableName;
	var tab = tableName.split(".");

	var sql = "select column_name || ' ' || data_type || CASE WHEN data_type = 'numeric' AND numeric_precision IS NOT NULL  THEN '('||numeric_precision||'.'||numeric_scale||')' ELSE '' END " +
		"|| CASE WHEN data_type = 'character' THEN '('||character_maximum_length||')' ELSE '' END|| CASE WHEN is_nullable <> 'YES' THEN ' NOT NULL' ELSE '' END" +
		"|| CASE WHEN column_default IS NOT NULL THEN ' default '||column_default ELSE '' END AS col from information_schema.columns " +
		"WHERE table_catalog = $1 AND table_schema = $2 AND table_name = $3 ORDER BY ordinal_position";

	var errorCb = function(e) {
		respondWithError(res, e);
	};

	var endCb = function(result) {
		getTableIndexes(serverId, databaseName, tableId, "CREATE TABLE " + tableName + "(\n" + _.map(result, 'col').join(',\n') + "\n);\n\n", req, res, errorCb);
	};

	executeSql(serverId, databaseName, sql, [databaseName, tab[0], tab[1]], endCb, errorCb);
};


function getTableIndexes(serverId, databaseName, tableId, defn, req, res, errorCb) {
	var sql = "SELECT c2.relname, i.indisprimary, i.indisunique, i.indisclustered, i.indisvalid, "
		+ "CASE WHEN contype IN ('p', 'u') THEN "
		+ "'ALTER TABLE ' || n.nspname || '.' || c.relname  || ' ADD CONSTRAINT '|| c2.relname || ' ' ||pg_catalog.pg_get_constraintdef(con.oid, true) ||';' "
		+ "ELSE pg_catalog.pg_get_indexdef(i.indexrelid, 0, true) || '; '"
		+ "END AS pg_get_indexdef, "
		+ "pg_catalog.pg_get_constraintdef(con.oid, true), contype, condeferrable, condeferred, c2.reltablespace "
		+ "FROM pg_catalog.pg_class c, pg_catalog.pg_class c2, pg_catalog.pg_namespace n, pg_catalog.pg_index i "
		+ "LEFT JOIN pg_catalog.pg_constraint con ON (conrelid = i.indrelid AND conindid = i.indexrelid AND contype IN ('p','u','x')) "
		+ "WHERE c.oid = $1 "
		+ "AND c.oid = i.indrelid "
		+ "AND c.relnamespace = n.oid "
		+ "AND i.indexrelid = c2.oid "
		+ "ORDER BY i.indisprimary DESC, i.indisunique DESC, c2.relname;";

	var endCb = function(result) {
		getTableChecks(serverId, databaseName, tableId, defn + _.map(result, 'pg_get_indexdef').join('\n') + '\n\n', req, res, errorCb);
	};

	executeSql(serverId, databaseName, sql, [tableId], endCb, errorCb);
}

function getTableChecks(serverId, databaseName, tableId, defn, req, res, errorCb) {
	var sql = "SELECT 'ALTER TABLE '||n.nspname||'.'||c.relname||' ADD CONSTRAINT '||r.conname||' '||pg_catalog.pg_get_constraintdef(r.oid, true)||';' AS con "
		+ "FROM pg_catalog.pg_constraint r, pg_catalog.pg_class c, pg_catalog.pg_namespace n "
		+ "WHERE r.conrelid = $1 AND r.contype IN ('c', 'f') AND c.oid = r.conrelid AND n.oid = r.connamespace "
		+ "ORDER BY 1;";

	var endCb = function(result) {
		getTableTriggers(serverId, databaseName, tableId, defn + _.map(result, 'con').join('\n') + '\n\n', req, res);
	};

	executeSql(serverId, databaseName, sql, [tableId], endCb, errorCb);
}

function getTableTriggers(serverId, databaseName, tableId, defn, req, res, errorCb) {
	var sql = "SELECT t.tgname, pg_catalog.pg_get_triggerdef(t.oid, true), t.tgenabled "
		+ "FROM pg_catalog.pg_trigger t "
		+ "WHERE t.tgrelid = $1 AND NOT t.tgisinternal "
		+ "ORDER BY 1; ";

	var endCb = function(result) {
		res.send(defn + _.map(result, 'pg_get_triggerdef').join('\n') + '\n\n');
	};

	executeSql(serverId, databaseName, sql, [tableId], endCb, errorCb);
}

exports.getTableStats = function(req, res) {
	var filter = (req.params.functionFilter == '*') ? '%' : '%' + req.params.functionFilter + '%';
	var sortCol = (!req.params.sortCol) ? "relname" : req.params.sortCol;
	var limit = (!req.params.queryLimit) ? 250 : parseInt(req.params.queryLimit);
	var sortOrder = (req.params.sortOrder == "DESC") ? "DESC" : "ASC";
	var sql = "/* pgmon */ SELECT relid, schemaname || '.' || relname AS relname, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, " +
		"n_tup_upd, n_tup_del, n_tup_hot_upd, n_live_tup, n_dead_tup, last_vacuum, last_autovacuum, last_analyze, " +
		"last_autoanalyze /*, vacuum_count, autovacuum_count, analyze_count, autoanalyze_count */ FROM pg_stat_user_tables " +
		"WHERE (schemaname || '.' || relname) ilike $1 ORDER BY " + sortCol + " " + sortOrder + " LIMIT $2";

	executeInRequestContextSimple(sql, [filter, limit], req, res);
};

function executeInRequestContextSimple(sql, params, req, res) {
	var serverId = req.params.id;
	var databaseName = dbServers[serverId].databaseName;

	var errorCb = function(e) {
		respondWithError(res, e);
	};

	var endCb = function(result) {
		res.send(JSON.stringify(result));
	};

	executeSql(serverId, databaseName, sql, params, endCb, errorCb);
}


function executeSql(serverId, databaseName, sql, params, endCb, errorCb) {
	var queryCb = function(conn) {
		var result = [];
		conn.query(sql, params)
			.on('error', function(err) {
				console.error("Error querying: " + sql);
				errorCb(err);
			})
			.on('data', function(data) {
				result.push(data);
			})
			.on('end', function() {
				endCb(result);
			});
	};

	executeOnServerDatabase(serverId, databaseName, queryCb, errorCb);
}

function respondWithError(res, err) {
	console.error(err.stack);
	res.send(500, err.message);
}


function executeOnServerDatabase(serverId, databaseName, queryCb, errorCb) {
	if(_.isUndefined(dbConnections[serverId])) {
		dbConnections[serverId] = {};
	}

	function connectionHandler(err, conn) {
		if(err) {
			return errorCb(err);
		}
		console.log("Connected to: " + uri);
		dbConnections[serverId][databaseName] = conn;
		return queryCb(dbConnections[serverId][databaseName]);
	}

	function connectionErrorHandler(err) {
		console.log("Connection error: " + err);
		if(dbConnections[serverId][databaseName]) {
			try {
				dbConnections[serverId][databaseName].end();
			} catch (e) {
			}

			delete dbConnections[serverId][databaseName];
		}
	}

	if(_.isUndefined(dbConnections[serverId][databaseName])) {
		if(dbServers[serverId].uri.split("//")[1].split("/")[1] === '') {
			var uri = dbServers[serverId].uri + dbServers[serverId].databaseName + '?application_name=reportmonitor';
		} else {
			var uri = dbServers[serverId].uri + '?application_name=reportmonitor';
		}
		pg.createConnection(uri, connectionHandler).on('error', connectionErrorHandler);
	} else {
		queryCb(dbConnections[serverId][databaseName]);
	}
}


'use strict';

process.title = require('./package.json').name.replace(/-/g, '_');

var http = require('http');
var express = require('express');
var path = require('path');
var app = exports.app = express();
var bodyParser = require('body-parser');
var morgan = require('morgan');
var favicon = require('serve-favicon');
var errorHandler = require('errorhandler');
var swagger = require('swagger-node-express');

var monitor = require('./routes/monitor');
var servers = require('./routes/servers');
var apps = require('./routes/apps');
var main = require('./routes/main');


app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(favicon('./public/favicon.ico'));
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'node_modules')));


app.get('/', main.index);

app.post('/api/:id/report/update', monitor.updateReport);

app.get('/api/:id/databases', monitor.listDatabases);
app.get('/api/servers', servers.list);
app.get('/api/apps', apps.list);
app.get('/api/:id/queries/:activeOnly?', monitor.listOnServer);
app.delete('/api/:id/query/:pid', monitor.killPid);
app.get('/api/:id/:database/functions/:functionFilter/:queryLimit/:sortOrder/:sortCol?', monitor.getFunctionTimes);
app.get('/api/:id/:database/tablestats/:functionFilter/:queryLimit/:sortOrder/:sortCol?', monitor.getTableStats);
app.get('/api/:id/:database/function/:functionId', monitor.getFunctionDefn);
app.get('/api/:id/:database/table/:tableId/:tableName', monitor.getTableDefn);
app.get('/api/:id/:database/functionsearch/:search', monitor.searchFunctionDefn);
app.get('/api/:id/:database/views/:search', monitor.searchViews);


if ('development' == app.get('env')) {
	app.use(errorHandler);
}

var server = http.createServer(app)
server.listen(app.get('port'), function () {
	console.log('Report Monitor listening on port ' + app.get('port'));
});
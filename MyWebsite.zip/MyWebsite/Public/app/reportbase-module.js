'use strict';

angular.module('reportmonitorbase', ["lodash"])
//.constant('_', window._)
.controller('BaseControllerCtrl', function ($scope, $http, _) {
	//$scope._ = _;
    var currentServer = 0;
    var currentDatabase = 0;

    $scope.servers = [];
    $scope.databases = [];
    $scope.showAll = "";
    $scope.hideAlerts = true;

    $scope.displayMessage = function(data) {
        $scope.errorMessage = (data && data != "") ?  data : "Unknown Error";
        $scope.hideAlerts = false;
    };

    $scope.setupServers = function() {
        $http.get('/api/servers')
            .success(function(data) {
                $scope.servers = data;
                if ($scope.servers.length > 0) {
                    $scope.serverSelection = $scope.servers[currentServer];
                }
            })
            .error(function(data) {
                $scope.servers = [];
                $scope.displayMessage("Error loading servers:" + JSON.stringify(data));
            });
    };

    $scope.setupServers();

    $scope.getCurrentServer = function() {
        return $scope.servers[currentServer];
    };

	$scope.getCurrentServerName = function() {
		return currentServer;
	};

    $scope.setServer = function(server) {
        $scope.hideAlerts = true;
	    if ($scope.tableReset) {
		    $scope.tableReset();
	    }
        currentServer = _.indexOf($scope.servers, server);
	    if ($scope.onServerSelection) {
		    $scope.onServerSelection();
	    }
        $scope.getDatabases();
    };

    $scope.getDatabases = function() {
        $scope.hideAlerts = true;
	    $scope.databases = [];

        $http.get('/api/' + currentServer + '/databases', {params: { 'database': 'app1' }})
            .success(function(data) {
                $scope.databases = data;
                if (data.length > 0) {
                    currentDatabase = _.indexOf($scope.databases, data[0]);
                }
            })
            .error(function(data) {
                $scope.displayMessage("Error listing databases: " + JSON.stringify(data));
            });
    };


	$scope.setDatabase = function(database) {
		$scope.hideAlerts = true;
		if ($scope.tableReset) {
			$scope.tableReset();
		}
		currentDatabase = _.indexOf($scope.databases, database);
		if ($scope.onDbSelection) {
			$scope.onDbSelection();
		}
	};

    $scope.getCurrentDatabase = function() {
        return $scope.databases[currentDatabase];
    };

	$scope.getCurrentDatabaseName = function() {
		var currDb = $scope.getCurrentDatabase();
		return !currDb ? "postgres" : currDb.dbname;

	};

	$scope.setColor = function(query) {
		var rgb = "#00bfff";
		if (query.secs < -60) {
			return { "background-color" : rgb };
		}
		if (query.state != "idle") {
			var nonIdle = 255 - Math.min(Math.round(Math.abs(query.secs) * 4.2), 255);
			rgb = "rgb(255," + nonIdle + "," + nonIdle + ")";
		} else {
			var idle = 255 - Math.min(Math.round((Math.abs(query.secs) + 10) * 4.2), 255);
			rgb = "rgb(" + idle + ",255," + idle + ")";
		}
		return { "background-color" : rgb };
	};

	$scope.getDatabases();
})

.filter('nl2br', function(){
	return function(text) {
		return text.replace(/\n/g, '<br/>');
	}
})

.directive('compile', function($compile) {
	return function(scope, element, attrs) {
		scope.$watch(
			function(scope) {
				// watch the 'compile' expression for changes
				return scope.$eval(attrs.compile);
			},
			function(value) {
				// when the 'compile' expression changes
				// assign it into the current DOM
				element.html(value);

				// compile the new DOM and link it to the current scope.
				$compile(element.contents())(scope);
			}
		);
	};
})

.directive('modal', function() {
	return {
		restrict: "E",
		transclude: false,
		replace: true,
		scope: {
			id: "&",
			label: "=",
			title: "=",
			body: "=",
			show: "&"
		},
		template: "<div class='modal fade' tabindex='-1' role='dialog' aria-labelledby='{{label}}' aria-hidden='true'>" +
			"<div class='modal-dialog'><div class='modal-content'><div class='modal-header'><span>{{title}}</span><button " +
			"type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button></br></div><div class='modal-body'>" +
			"<pre>{{body}}</pre></div><div class='modal-footer'><button type='button' class='btn btn-default' " +
			"data-dismiss='modal'>Close</button></div></div></div>"
	}
})


.directive('appSelector', function() {
	return {
		restrict: "E",
		transclude: false,
		replace: true,
		scope: {
			apps: "&",
			onclickshow: "="
		},

		controller: function($scope, $http) {
			$scope.apps = [];

			$scope.setupApps = function() {
				$http.get('/api/apps')
					.success(function(data) {
						$scope.apps = data;
					})
					.error(function(data) {
						$scope.apps = [];
						$scope.displayMessage("Error loading apps:" + JSON.stringify(data));
					});
			};

			$scope.myOnClick = function() {
				if ($scope.onclickshow) {
					$scope.onclickshow();
				}
			};

			$scope.setServer = function(server) {
				$scope.hideAlerts = true;
				if ($scope.tableReset) {
					$scope.tableReset();
				}
				var currentServer = _.indexOf($scope.servers, server);
				if ($scope.onServerSelection) {
					$scope.onServerSelection();
				}
				$scope.getDatabases();
			};


			$scope.setupApps();
		},
		template: "<li class='dropdownaaa'><a href='monitor' class='dropdown-toggle' data-toggle='dropdown' ng-click='myOnClick()'>Menu<b class='caret'></b></a>" +
				"<ul class='dropdown-menu'><li ng-repeat='app in apps' ><a href='{{app.url}}'>{{app.name}}</a></li></ul></li>"
	}
})
;
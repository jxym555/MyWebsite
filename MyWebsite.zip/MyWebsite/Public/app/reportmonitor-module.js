'use strict';

angular.module('reportmonitor', ["lodash", "reportmonitorbase"])

	.controller('QueriesCtrl', function($scope, $http, $timeout, $controller) {
		$controller('BaseControllerCtrl', {$scope : $scope});

		var currentInterval = 2;
		var delayRefresh = false;
		var currentReport = {};
		$scope.hideEdit = true;

		$scope.activeOnly = "active";

		$scope.intervals = [
			{name : "1 second refresh", value : 1000},
			{name : "2 second refresh", value : 2000},
			{name : "5 second refresh", value : 5000},
			{name : "10 second refresh", value : 10000},
			{name : "30 second refresh", value : 30000},
			{name : "Never refresh", value : -1}
		];

		$scope.updateReport = function() {
			var url = '/api/' + $scope.getCurrentServerName() + '/report/update';
			var data = {};
			$("#reportForm input").each(function(index, value) {
				data[value.id] = value.value;
			});
			$http.post(url, data)
				.success(function(data) {
					$scope.hideEdit = true;
					alert('success!');
					$scope.getQueries();
					return false;
				})
				.error($scope.displayMessage);
		};

		$scope.updateReportView = function(reportIndex) {
			$scope.hideEdit = false;
			currentReport = $scope.queries[reportIndex];
			$("input").each(function(index, value) {
				var id = value.id;
				if(id) {
					value.value = currentReport[id];
				}
			});
		};

		$scope.tableReset = function() {
			$scope.queries = [];
			delayRefresh = false;
		};

		$scope.getCurrentInterval = function() {
			return $scope.intervals[currentInterval];
		};

		$scope.setInterval = function(interval) {
			currentInterval = _.indexOf($scope.intervals, interval);
			$scope.setupRefreshTimer(interval);
		};

		$scope.getQueries = function(resetDelayRefresh) {
			if(resetDelayRefresh) {
				delayRefresh = false;
			}
			if(delayRefresh == false) {
				$http.get('/api/' + $scope.getCurrentServerName() + '/queries/' + $scope.activeOnly)
					.success(function(data) {
						$scope.queries = data;
					})
					.error($scope.displayMessage);
			}
		};


		$scope.killQuery = function(item) {
			if(_.contains($scope.queries, item) > -1) {
				$http.delete('/api/' + $scope.getCurrentServerName() + '/query/' + item.pid)
					.success(function() {
						$scope.displayMessage("killed " + item.pid);
					})
					.error($scope.displayMessage);
			}
		};

		$scope.togglePauseRefresh = function() {
			delayRefresh = !delayRefresh;
		};

		$scope.delayRefresh = function() {
			delayRefresh = true;
			$timeout(function() {
				delayRefresh = false;
			}, 10000);
		};

		$scope.setupRefreshTimer = function(refresh) {
			delayRefresh = false;
			if(!angular.isUndefined($scope.intervalTimer)) {
				clearInterval($scope.intervalTimer);
			}
			if(refresh.value > 0) {
				$scope.intervalTimer = setInterval($scope.getQueries, refresh.value);
			}
		};

		$scope.setupRefreshTimer($scope.getCurrentInterval());
	})
;